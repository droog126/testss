function Counter() {
    const [count, setCount] = useState(0);
  
    useEffect(() => {
      const id = setInterval(() => {
        setCount(c => c + 1); // ✅ 在这不依赖于外部的 `count` 变量
      }, 1000);
      return () => clearInterval(id);
    }, []); // ✅ 我们的 effect 不使用组件作用域中的任何变量
  
    return <h1>{count}</h1>;
}
  
/*
注意这种方式在循环中是无效的，因为 Hook 调用 不能 被放在循环中。但你可以为列表项抽取一个单独的组件，并在其中调用 useMemo。



*/