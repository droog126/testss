import React from 'react'

export default function Line() {
    return (
        <div className="bg-black h-full w-1">
            
        </div>
    )
}
