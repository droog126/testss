import React, {  Fragment, useEffect,useRef } from 'react'
import MButton from 'components/Button'
import { render } from 'react-dom'
export default function Modal(props) {

    useEffect(() => {
        const event = (e) => {
            console.log(e.target);
            if (e.target == outerDom.current) {
                console.log('点到外面了');
                let dom = document.getElementById('modal');
                dom.classList.add('invisible');
            }
        }
        document.addEventListener('click', event);
        return () => {
            document.removeEventListener('click',event);
        }
        
    },[])
    const handleClick = (e) => {
        var dom = document.getElementById('modal');
        dom.classList.remove('invisible');
    }
    const outerDom = useRef(null);
    const view = (
        <Fragment>
            <div className='h-screen w-screen fixed bg-black opacity-20 inset-0' ref={outerDom}>

            </div>
            <div className={`z-10  fixed inset-0 m-auto ${props.className} `}>
                {props.children}
            </div>
        </Fragment>
        
    )
    useEffect(() => {
        var dom = document.createElement('div');
        dom.classList.add('invisible','relative');
        dom.id = 'modal';
        document.body.appendChild(dom);
        render(view,dom)
        return ()=>{document.body.removeChild(dom)}
    }, [])
    return (
        <MButton onClick={handleClick}>
            打开模态
        </MButton>
    )
}
