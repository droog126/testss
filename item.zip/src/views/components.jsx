import React,{useState,Suspense,useCallback,useMemo, createElement, Fragment, useEffect} from 'react'
import MInput from 'components/Input'
import ErrorBoundary from '../components/ErrorBoundary'
import { JsonTable } from 'react-json-to-html';
import { Route, Switch, NavLink, Link, useRouteMatch } from 'react-router-dom'
import MButtonGroup from 'components/ButtonGroup'



export default function View({ }) {
    // loadComponentCache();

  
    const [componentName, setComponentName] = useState("Button");
    const [freshDep, setFreshDep] = useState(1)
    const [componentProps, setComponentProps] = useState("{}")
    console.log(componentName)


    const correctComponentProps = useMemo(() => {
        try {
            return JSON.parse(componentProps);
        } catch (error) {
            return {}
        }

    }, [freshDep]);


    const DynamicComponent = useMemo(() => React.lazy(() => import(`../components/${componentName}.jsx`)), [freshDep])

    const handleChangeComponentProps = useCallback((e) => { setComponentProps(e.target.value) }, []);

    const handleChangeComponentName = useCallback((e) => { setComponentName(e.target.value) }, []);
    
    const handleComponentChange = useCallback(() => {

        //我没有他渲染前的钩子
        saveComponentCache();
        setFreshDep(-freshDep)
    }, [freshDep])

    useEffect(() => {
        loadComponentCache();
    }, [])
    


    //缓存逻辑
    function loadComponentCache() {
        let data = localStorage.getItem('componentCache');
        if (data) {
            console.log('我加载了缓存？')
            data = JSON.parse(data);
            setComponentName(data.name);
            setComponentProps(data.props);
            handleComponentChange();
        }
        
    }
    
    function saveComponentCache() {
        let data = {
            name: componentName,
            props:componentProps,
        }
        localStorage.setItem('componentCache', JSON.stringify(data));
        console.log(data);
        console.log('我更新了缓存?')
    }



    //按键组逻辑
    const selectGroup = ['组件名修改', '组件属性修改'];
    const [select, setSelect] = useState(0);
    const GetSelect = useCallback((select) => { setSelect(select) }, [])


    const SelectView = useCallback((props) => {
        console.log(props);
        const { componentName, componentProps ,handleComponentChange} = props.updateDep;
        switch (select) {
            case 0:
                return <MInput value={componentName} onChange={handleChangeComponentName} enter={handleComponentChange} full></MInput>
                break;
            case 1:
                return <MInput value={componentProps} onChange={handleChangeComponentProps} enter={handleComponentChange} full></MInput>
                break;
            default:
                return <div>你没有写选择后的结果</div>
                break;
        }
    }, [select]);
   

    return (
        <Fragment>

            <div className='flex h-80 justify-start border-2 border-black w-screen'>
                <div className='absolute border'>
                    {componentName}
                </div>
                <div className='w-2/3 flex justify-center items-center h-80 flex-shrink-0'>
                    <ErrorBoundary>
                        <Suspense fallback={<div>loding...</div>}>
                            {createElement(DynamicComponent,correctComponentProps)}
                        </Suspense>
                    </ErrorBoundary>
                </div>
                <div className='flex-grow-1 flex-shrink-0 border-l-2 border-black'>
                    <JsonTable json={correctComponentProps}></JsonTable>
                </div>
            </div>
         
           

            
        
            <MButtonGroup getSelect={GetSelect} selectGroup={selectGroup} select={select}></MButtonGroup>
            <SelectView updateDep={ {componentName, componentProps,handleComponentChange} }/>


            <div className='text-blue-500 text-right font-bold'>
                ps:双击两下才可以缓存当前值
            </div>
          
        </Fragment>
       
    )
}
